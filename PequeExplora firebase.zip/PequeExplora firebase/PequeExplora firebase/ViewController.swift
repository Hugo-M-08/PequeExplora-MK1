//
//  ViewController.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 05/12/25.
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var LBL_Registrarse: UILabel!
    @IBOutlet weak var SW_SesionActiva: UISwitch!
    @IBOutlet weak var BTN_Ingresar: UIButton!
    @IBOutlet weak var TF_Contraseña: UITextField!
    @IBOutlet weak var TF_CorreoElectronico: UITextField!

    // Clave para guardar la preferencia en UserDefaults
    let keepLoggedInKey = "keepLoggedInPreference"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1. LÓGICA DE AUTO-LOGIN
        let shouldAutoLogin = UserDefaults.standard.bool(forKey: keepLoggedInKey)
        let currentUser = Auth.auth().currentUser
        
        // Si la preferencia está activa Y hay un usuario de Firebase activo
        if shouldAutoLogin && currentUser != nil {
            DispatchQueue.main.async {
                self.performSegue(withIdentifier: "irMain", sender: nil)
            }
        }
        
        // Configurar el estado inicial del switch basado en lo guardado
        SW_SesionActiva.isOn = shouldAutoLogin
        
        // Configuración de acciones de UI
        BTN_Ingresar.addTarget(self, action: #selector(iniciarSesion), for: .touchUpInside)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(irARegistro))
        LBL_Registrarse.isUserInteractionEnabled = true
        LBL_Registrarse.addGestureRecognizer(tapGesture)
        
        // Configuración para cerrar el teclado
        setupTapGesture()
    }
    
    // MARK: - Configuración de Teclado
    
    // Configura el gesto para ocultar el teclado al tocar fuera
    func setupTapGesture() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    // Oculta el teclado
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    // MARK: - Funciones de Login

    @objc func iniciarSesion() {
        // Validación de campos
        guard let email = TF_CorreoElectronico.text, !email.isEmpty,
              let password = TF_Contraseña.text, !password.isEmpty else {
            self.mostrarAlerta(titulo: "Error", mensaje: "Ingresa correo y contraseña.")
            return
        }

        // Iniciar sesión con Firebase Authentication
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] authResult, error in
            guard let self = self else { return }

            if let e = error {
                self.mostrarAlerta(titulo: "Error de Login", mensaje: e.localizedDescription)
                return
            }

            // Éxito: Usuario ha iniciado sesión
            guard let user = authResult?.user else { return }

            // 2. Bloquear el acceso si el correo no está verificado
            if user.isEmailVerified {
                
                // GUARDAR PREFERENCIA DEL SWITCH
                let shouldKeepLoggedIn = self.SW_SesionActiva.isOn
                UserDefaults.standard.set(shouldKeepLoggedIn, forKey: self.keepLoggedInKey)
                
                // Verificado: Acceso concedido
                self.performSegue(withIdentifier: "irMain", sender: self)
                
            } else {
                // No verificado: Denegar acceso y notificar al usuario
                try? Auth.auth().signOut() // Cerrar sesión
                self.mostrarAlerta(titulo: "Verificación Requerida",
                                   mensaje: "Tu correo electrónico no ha sido verificado. Revisa tu bandeja de entrada o haz clic en 'OK' para reenviar el correo de verificación.",
                                   accion: {
                                     user.sendEmailVerification(completion: nil)
                                   })
            }
        }
    }
    
    @objc func irARegistro() {
        self.performSegue(withIdentifier: "irRegistro", sender: self)
    }

    // Función de ayuda para mostrar alertas (con acción opcional de cierre)
    func mostrarAlerta(titulo: String, mensaje: String, accion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: titulo, message: mensaje, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            accion?()
        }
        alert.addAction(okAction)
        present(alert, animated: true)
    }
}
