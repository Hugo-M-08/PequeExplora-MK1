//
//  VerPerfil.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore
import AVFoundation

class VerPerfil: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK: - Outlets
    @IBOutlet weak var LBL_MostrarPuntos: UILabel!
    @IBOutlet weak var BTN_CerrarSesion: UIButton!
    @IBOutlet weak var BTN_CambiarFoto: UIButton!
    @IBOutlet weak var LBL_NombreUsuario: UILabel!
    @IBOutlet weak var LBL_Correo: UILabel!
    @IBOutlet weak var BTN_Regresar: UIButton!
    @IBOutlet weak var LBL_PosicionRanking: UILabel!
    @IBOutlet weak var FotoPerfil: UIImageView!
    
    // MARK: - Propiedades
    let db = Firestore.firestore()
    let keepLoggedInKey = "keepLoggedInPreference"
    var audioPlayer: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        cargarInformacionUsuario()
        cargarPosicionYPuntuacion()
        BTN_CerrarSesion.addTarget(self, action: #selector(cerrarSesion), for: .touchUpInside)
        BTN_Regresar.addTarget(self, action: #selector(regresar), for: .touchUpInside)
        BTN_CambiarFoto.addTarget(self, action: #selector(abrirGaleria), for: .touchUpInside)
    }
    
    
    func cargarInformacionUsuario() {
        guard let currentUser = Auth.auth().currentUser else {
            LBL_NombreUsuario.text = "Error de sesión"
            return
        }
        
        LBL_Correo.text = currentUser.email
        
        let docRef = db.collection("usuarios").document(currentUser.uid)
                         .collection("informacionDeUsuario").document("datos")
        
        docRef.getDocument { [weak self] (document, error) in
            guard let self = self else { return }
            
            if let document = document, document.exists {
                let data = document.data()
                
                if let nombre = data?["nombre"] as? String {
                    self.LBL_NombreUsuario.text = nombre
                } else {
                    self.LBL_NombreUsuario.text = "Nombre no encontrado"
                }
                
                if let fotoBase64 = data?["fotoBase64"] as? String, !fotoBase64.isEmpty {
                    self.mostrarImagenDesdeBase64(base64String: fotoBase64)
                } else {
                    self.FotoPerfil.image = UIImage(systemName: "person.circle.fill")
                }
            } else {
                print("Documento de usuario no encontrado en Firestore.")
                self.LBL_NombreUsuario.text = "Datos no disponibles"
            }
        }
    }
    




    func cargarPosicionYPuntuacion() {
        guard let currentUID = Auth.auth().currentUser?.uid else {
            print("DEBUG: ❌ Usuario no autenticado.")
            LBL_PosicionRanking.text = "Posición: No autenticado"
            LBL_MostrarPuntos.text = "Mejor Puntuación: 0"
            return
        }

        print("DEBUG: ✅ UID autenticado y consultado: \(currentUID)")
        
        // 1. Encontrar la MEJOR PUNTUACIÓN del usuario usando el UID
        db.collection("Ranking")
            .whereField("usuario", isEqualTo: currentUID)
            .order(by: "puntos", descending: true)      // <--- USAMOS EL ORDEN
            .limit(to: 1)
            .getDocuments { [weak self] (snapshot, error) in
                
                guard let self = self else { return }
                
                if let error = error {
                    print("DEBUG: ❌ Error en la consulta de Ranking (Paso 1): \(error.localizedDescription)")
                    DispatchQueue.main.async { self.LBL_MostrarPuntos.text = "Error de consulta" }
                    return
                }

                guard let snapshot = snapshot, let mejorRegistro = snapshot.documents.first else {
                    print("DEBUG: 📊 Documentos encontrados para el UID: 0. (Sin registros)")
                    DispatchQueue.main.async {
                        self.LBL_PosicionRanking.text = "Posición en el Ranking: --"
                        self.LBL_MostrarPuntos.text = "Mejor Puntuación: 0"
                    }
                    return
                }
                
                // Decodificación robusta de PUNTOS
                var mejorPuntuacion: Int = 0
                
                if let puntosInt = mejorRegistro.data()["puntos"] as? Int {
                    mejorPuntuacion = puntosInt
                } else if let puntosNum = mejorRegistro.data()["puntos"] as? NSNumber {
                    mejorPuntuacion = puntosNum.intValue
                } else {
                    print("DEBUG: ❌ ERROR DE CASTING: El campo 'puntos' no es Int ni NSNumber.")
                    DispatchQueue.main.async {
                        self.LBL_MostrarPuntos.text = "Error de tipo de puntos."
                    }
                    return
                }
                
                print("DEBUG: ✅ Mejor Puntuación decodificada: \(mejorPuntuacion)")

                // Muestra la mejor puntuación
                DispatchQueue.main.async {
                    self.LBL_MostrarPuntos.text = "Mejor Puntuación: \(mejorPuntuacion)"
                }
                
                // 2. Contar cuántos tienen una puntuación ESTRICTAMENTE MAYOR
                self.db.collection("Ranking")
                    .whereField("puntos", isGreaterThan: mejorPuntuacion)
                    .order(by: "puntos", descending: true) // <--- USAMOS EL ORDEN AQUÍ TAMBIÉN
                    .getDocuments { (globalSnapshot, globalError) in
                        
                        guard let globalSnapshot = globalSnapshot else { return }
                        
                        let posicion = globalSnapshot.documents.count + 1
                        
                        DispatchQueue.main.async {
                            self.LBL_PosicionRanking.text = "Posición en el Ranking: \(posicion)"
                        }
                        print("DEBUG: ✅ Posición calculada: \(posicion)")
                    }
            }
    }
    
    
    
    
    // Convierte la cadena Base64 en UIImage y la muestra
    func mostrarImagenDesdeBase64(base64String: String) {
        if let imageData = Data(base64Encoded: base64String, options: .ignoreUnknownCharacters),
            let image = UIImage(data: imageData) {
            
            self.FotoPerfil.image = image
        } else {
            self.FotoPerfil.image = UIImage(systemName: "photo.fill")
            print("Error al decodificar la cadena Base64.")
        }
    }
    
    @objc func abrirGaleria() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    
    func actualizarFotoEnFirestore(image: UIImage) {
        guard let currentUser = Auth.auth().currentUser else { return }
        
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            self.mostrarAlerta(titulo: "Error de Imagen", mensaje: "No se pudo procesar la imagen.")
            return
        }
        let base64String = imageData.base64EncodedString()
        
        let userDocRef = db.collection("usuarios").document(currentUser.uid)
                             .collection("informacionDeUsuario").document("datos")
        
        userDocRef.updateData(["fotoBase64": base64String]) { error in
            if let e = error {
                self.mostrarAlerta(titulo: "Error de Actualización", mensaje: "No se pudo subir la foto: \(e.localizedDescription)")
            } else {
                self.mostrarAlerta(titulo: "Éxito", mensaje: "Tu foto de perfil ha sido actualizada.")
                // 4. Actualizar la UIImageView localmente
                self.FotoPerfil.image = image
            }
        }
    }

    
    func playSound(_ name: String) {
        if let url = Bundle.main.url(forResource: name, withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            } catch {
                print("Error al reproducir \(name): \(error)")
            }
        }
    }

    
    @objc func regresar() {
        playSound("Sonido")
        self.performSegue(withIdentifier: "regreso4", sender: self)
    }

    @objc func cerrarSesion() {
        playSound("Sonido")
        UserDefaults.standard.set(false, forKey: keepLoggedInKey)
        
        do {
            try Auth.auth().signOut()
            self.performSegue(withIdentifier: "irLogin2", sender: self)
        } catch let signOutError as NSError {
            self.mostrarAlerta(titulo: "Error al cerrar sesión", mensaje: signOutError.localizedDescription)
        }
    }
    
    
    func mostrarAlerta(titulo: String, mensaje: String) {
        let alert = UIAlertController(title: titulo, message: mensaje, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alert.addAction(okAction)
        present(alert, animated: true)
    }
}

extension VerPerfil {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        
        guard let selectedImage = (info[.editedImage] as? UIImage) ?? (info[.originalImage] as? UIImage) else {
            return
        }
        
        actualizarFotoEnFirestore(image: selectedImage)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}
