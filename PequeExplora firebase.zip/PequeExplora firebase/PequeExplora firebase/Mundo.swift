//
//  Mundo.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//
import UIKit
import CoreLocation
import MapKit
import AVFoundation
import Firebase
import FirebaseFirestore

class Mundo: UIViewController, CLLocationManagerDelegate {

    // MARK: - Outlets y Propiedades
    
    // Conecta estos Outlets a sus respectivos elementos en tu Storyboard
    @IBOutlet weak var BTN_Regresar: UIButton!
    @IBOutlet weak var BTN_PiramideGiza: UIButton!
    @IBOutlet weak var BTN_ColosoRodas: UIButton!
    @IBOutlet weak var BTN_Zeus: UIButton!
    @IBOutlet weak var Mapita: MKMapView!
    @IBOutlet weak var BTN_JardinesBabilonia: UIButton!
    @IBOutlet weak var BTN_FaroAlejandría: UIButton!
    @IBOutlet weak var BTN_MausoleoHalicarnaso: UIButton!
    @IBOutlet weak var BTN_TemploArtemisa: UIButton!
    
    var audioPlayer: AVAudioPlayer?
    let locationManager = CLLocationManager()
    let synthesizer = AVSpeechSynthesizer()

    // Referencia a Firestore
    let db = Firestore.firestore()

    // Diccionario para almacenar las maravillas cargadas
    var maravillasCargadas: [String: Maravilla] = [:]

    // MARK: - Ciclo de Vida
    
    override func viewDidLoad() {
        super.viewDidLoad()

        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()

        Mapita.mapType = .hybrid
        Mapita.isZoomEnabled = true
        Mapita.isScrollEnabled = true
        Mapita.showsBuildings = true
        
        cargarMaravillas()
    }

    // MARK: - Firebase: Carga de Datos (DECODIFICACIÓN MANUAL Y ROBUSTA)
    
    func cargarMaravillas() {
        let maravillasRef = db.collection("Mundo")
                              .document("maravillas")
                              .collection("informacion")

        maravillasRef.getDocuments { [weak self] (querySnapshot, error) in
            
            // CORRECCIÓN: Manejamos directamente la constante 'error'
            if let error = error {
                print("🚨 Error de conexión o permisos en Firebase: \(error.localizedDescription)")
                return
            }

            guard let self = self else { return }

            // Transfiere el trabajo al Hilo Principal (DispatchQueue.main.async)
            DispatchQueue.main.async {
                
                guard let documents = querySnapshot?.documents else {
                    print("⚠️ No se encontraron documentos en la subcolección 'informacion'.")
                    return
                }

                // Decodificación Manual (código restante sin cambios)
                for document in documents {
                    let data = document.data()
                    let keyId = document.documentID
                    
                    // Usamos NSNumber para mayor compatibilidad
                    guard let nombre = data["nombre"] as? String,
                          let descripcion = data["descripcion"] as? String,
                          let latitud_num = data["latitud"] as? NSNumber,
                          let longitud_num = data["longitud"] as? NSNumber
                    else {
                        print("❌ FALLÓ LA DECODIFICACIÓN del documento \(keyId). Verifica EXACTAMENTE los nombres de campo y que Lat/Lon sean tipo 'Number' en Firebase.")
                        continue
                    }

                    // Conversión a Double
                    let latitud = latitud_num.doubleValue
                    let longitud = longitud_num.doubleValue
                    
                    // Creamos la instancia
                    let maravilla = Maravilla(id: keyId,
                                              nombre: nombre,
                                              descripcion: descripcion,
                                              latitud: latitud,
                                              longitud: longitud)
                    
                    self.maravillasCargadas[keyId] = maravilla
                }
                
                print("✅ Maravillas cargadas exitosamente: \(self.maravillasCargadas.count) / 7")
                
                // Centrar el mapa al finalizar la carga
                if let giza = self.maravillasCargadas[MaravillaKey.piramideGiza.rawValue] {
                     self.centrarMapaEnCoordenadas(lat: giza.latitud, long: giza.longitud)
                }
            }
        }
    }
    // MARK: - Funciones Auxiliares
    
    func manejarAccionBoton(para key: MaravillaKey) {
        let keyString = key.rawValue
        
        // Busca en el diccionario cargado
        guard let maravilla = maravillasCargadas[keyString] else {
            print("⚠️ Dato de maravilla no encontrado para: \(keyString). El diccionario está vacío o incompleto.")
            return
        }

        leerDescripcion(descripcion: maravilla.descripcion)
        centrarMapaEnCoordenadas(lat: maravilla.latitud, long: maravilla.longitud)
    }

    func centrarMapaEnCoordenadas(lat: Double, long: Double) {
        let center = CLLocationCoordinate2D(latitude: lat, longitude: long)
        let viewRegion = MKCoordinateRegion(center: center, latitudinalMeters: 1000, longitudinalMeters: 1000)
        Mapita.setRegion(viewRegion, animated: true)
    }

    func leerDescripcion(descripcion: String) {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
        let utterance = AVSpeechUtterance(string: descripcion)
        let language = "es-MX"

        if let voice = AVSpeechSynthesisVoice(language: language) {
            utterance.voice = voice
            utterance.rate = 0.5
            synthesizer.speak(utterance)
        } else {
            print("No se encontró voz para \(language)")
        }
    }

    // MARK: - Acciones de Botón (@IBAction)

    @IBAction func actionBTN_PiramideGiza(_ sender: UIButton) {
        manejarAccionBoton(para: .piramideGiza)
    }

    @IBAction func actionBTN_ColosoRodas(_ sender: UIButton) {
        manejarAccionBoton(para: .colosoRodas)
    }

    @IBAction func actionBTN_Zeus(_ sender: UIButton) {
        manejarAccionBoton(para: .estatuaZeus)
    }

    @IBAction func actionBTN_JardinesBabilonia(_ sender: UIButton) {
        manejarAccionBoton(para: .jardinesBabilonia)
    }

    @IBAction func actionBTN_FaroAlejandría(_ sender: UIButton) {
        manejarAccionBoton(para: .faroAlejandria)
    }

    @IBAction func actionBTN_MausoleoHalicarnaso(_ sender: UIButton) {
        manejarAccionBoton(para: .mausoleoHalicarnaso)
    }

    @IBAction func actionBTN_TemploArtemisa(_ sender: UIButton) {
        manejarAccionBoton(para: .temploArtemisa)
    }
    
    @IBAction func actionBTN_Regresar(_ sender: Any) {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
        performSegue(withIdentifier: "regreso2", sender: nil)
        playSound()
    }
    
    func playSound() {
        guard let url = Bundle.main.url(forResource: "Sonido", withExtension: "mp3") else { return }
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Error reproduciendo el sonido: \(error.localizedDescription)")
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            Mapita.showsUserLocation = true
        }
    }
}
