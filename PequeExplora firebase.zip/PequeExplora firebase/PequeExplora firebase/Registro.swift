//
//  Registro.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 07/12/25.
//
import UIKit
import FirebaseAuth
import FirebaseFirestore

// La clase adopta los protocolos para la gestión de la galería
class Registro: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var BTN_Volver: UIButton!
    // MARK: - Outlets
    @IBOutlet weak var BTN_Ingresar: UIButton!
    @IBOutlet weak var BTN_SubirFoto: UIButton!
    @IBOutlet weak var TF_ConfContrasena: UITextField!
    @IBOutlet weak var TF_Contrasena: UITextField!
    @IBOutlet weak var TF_CorreoElectronico: UITextField!
    @IBOutlet weak var TF_Nombre: UITextField!

    // MARK: - Propiedades
    let db = Firestore.firestore()
    var selectedImage: UIImage? // Almacena la imagen seleccionada

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configuración de acciones
        BTN_Ingresar.addTarget(self, action: #selector(registrarUsuario), for: .touchUpInside)
        BTN_SubirFoto.addTarget(self, action: #selector(abrirGaleria), for: .touchUpInside)
        
        // Configuración para cerrar el teclado al tocar la vista
        setupTapGesture()
    }

    // MARK: - Configuración de Teclado
    
    // Configura el gesto para ocultar el teclado al tocar fuera
    func setupTapGesture() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    // Oculta el teclado
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    // MARK: - Funciones de Registro

    @objc func registrarUsuario() {
        // Validación de campos obligatorios
        guard let nombre = TF_Nombre.text, !nombre.isEmpty,
              let email = TF_CorreoElectronico.text, !email.isEmpty,
              let password = TF_Contrasena.text, !password.isEmpty,
              let confPassword = TF_ConfContrasena.text, !confPassword.isEmpty else {
            self.mostrarAlerta(titulo: "Error", mensaje: "Completa todos los campos.")
            return
        }

        if password != confPassword {
            self.mostrarAlerta(titulo: "Error", mensaje: "Las contraseñas no coinciden.")
            return
        }

        // 1. Crear usuario en Firebase Authentication
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] authResult, error in
            guard let self = self else { return }

            if let e = error {
                self.mostrarAlerta(titulo: "Error", mensaje: e.localizedDescription)
                return
            }

            // Éxito: Usuario creado
            guard let user = authResult?.user else { return }
            
            // 2. Enviar correo de verificación
            user.sendEmailVerification(completion: nil)
            
            // 3. Guardar información en Firestore (incluyendo la foto en Base64)
            self.guardarInformacionUsuario(user: user, nombre: nombre, email: email) { success in
                if success {
                    self.mostrarAlerta(titulo: "¡Registro Exitoso!", mensaje: "Cuenta creada. Por favor, verifica tu correo antes de iniciar sesión.", accion: {
                        self.performSegue(withIdentifier: "irLogin", sender: self)
                    })
                } else {
                    self.mostrarAlerta(titulo: "Error", mensaje: "No se pudo guardar la información de usuario.")
                }
            }
        }
    }

    // Función para guardar los datos y la foto en Base64 en Firestore
    func guardarInformacionUsuario(user: User, nombre: String, email: String, completion: @escaping (Bool) -> Void) {
        let uid = user.uid
        var base64String = ""
        
        // Conversión de UIImage a Base64 String
        if let image = selectedImage, let imageData = image.jpegData(compressionQuality: 0.8) {
            base64String = imageData.base64EncodedString()
        }

        let userData: [String: Any] = [
            "nombre": nombre,
            "correoElectronico": email,
            "fotoBase64": base64String, // Guardamos la foto en Base64
            "emailVerified": user.isEmailVerified
        ]

        // Estructura: usuarios > [uid] > informacionDeUsuario > datos
        let userDocRef = db.collection("usuarios").document(uid).collection("informacionDeUsuario").document("datos")
        
        userDocRef.setData(userData) { error in
            completion(error == nil)
        }
    }
    
    // MARK: - Funciones de Galería

    @objc func abrirGaleria() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    @IBAction func BTN_Volver(_ sender: Any) {
        self.performSegue(withIdentifier: "irLogin", sender: self)
    }
    
    // Función de ayuda para mostrar alertas
    func mostrarAlerta(titulo: String, mensaje: String, accion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: titulo, message: mensaje, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            accion?()
        }
        alert.addAction(okAction)
        present(alert, animated: true)
    }
}

// MARK: - Extensiones para UIImagePickerControllerDelegate

extension Registro {
    
    // Se llama cuando se selecciona una imagen
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.editedImage] as? UIImage {
            selectedImage = image
        } else if let image = info[.originalImage] as? UIImage {
            selectedImage = image
        }
        
        picker.dismiss(animated: true)
        
        // Actualiza el botón para indicar que la foto fue seleccionada
        BTN_SubirFoto.setTitle("¡Foto Seleccionada! (Lista)", for: .normal)
    }

    // Se llama si el usuario cancela la selección
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}
