//
//  Principal.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//

import UIKit
import WebKit
import AVFoundation
import Firebase
import FirebaseStorage


class Principal: UIViewController {

    @IBOutlet weak var BTN_Perfil: UIButton!
    @IBOutlet weak var BTN_Trivia: UIButton!
    @IBOutlet weak var BTN_Internet: UIButton!
    @IBOutlet weak var BTN_Mundo: UIButton!
    @IBOutlet weak var BTN_Alimentos: UIButton!
    @IBOutlet weak var BTN_Colores: UIButton!
    @IBOutlet weak var BTN_Animales: UIButton!
    @IBOutlet weak var BTN_Figuras: UIButton!
    @IBOutlet weak var BTN_Familia: UIButton!

    var vocabulary: [String] = Array(repeating: "", count: 10)
    var videoNames: [String] = Array(repeating: "", count: 10) // Solo nombre base
    var audioPlayer: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Inicializar Firebase (solo una vez en toda la app)
        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }

    // Función para generar URL de Firebase según categoría, índice e idioma
    func firebaseVideoURL(category: String, videoName: String, isEnglish: Bool) -> URL? {
        let lang = isEnglish ? "Ingles" : "Espanol"
        let folder: String
        
        switch category {
        case "animals":   folder = "Animales"
        case "figures":   folder = "Figuras"
        case "colors":    folder = "Colores"
        case "family":    folder = "Familia"
        case "foods":     folder = "Alimentos"
        default: return nil
        }
        
        // Construimos la ruta completa
        let path = "Vocabulario/Videos/\(lang)/\(folder)/\(videoName)\(isEnglish ? "ingles" : "").mp4"
        let storage = Storage.storage()
        let storageRef = storage.reference(forURL: "gs://klkgg-e40f9.firebasestorage.app")
        let videoRef = storageRef.child(path)
        
        // Obtenemos URL pública (puedes cachearla si quieres)
        var url: URL?
        videoRef.downloadURL { downloadedURL, error in
            if let downloadedURL = downloadedURL {
                url = downloadedURL
            }
        }
        
        // Nota: esto es asíncrono, por eso se maneja en Vocabulario
        return url // Temporalmente nil hasta que se resuelva
    }

    // === Acciones de botones (solo cambian los datos, el resto igual) ===

    @IBAction func BTN_Animales(_ sender: Any) {
        vocabulary = ["Perro", "Gato", "Elefante", "León", "Tigre", "Mono", "Oso", "Zorro", "Pájaro", "Serpiente"]
        videoNames = ["animal1", "animal2", "animal3", "animal4", "animal5", "animal6", "animal7", "animal8", "animal9", "animal10"]
        performSegue(withIdentifier: "irBotonera", sender: ["category": "animals"])
        playSound()
    }

    @IBAction func BTN_Figuras(_ sender: Any) {
        vocabulary = ["Círculo", "Cuadrado", "Triángulo", "Rectángulo", "Pentágono", "Hexágono", "Cubo", "Esfera", "Cono", "Cilindro"]
        videoNames = ["figura1", "figura2", "figura3", "figura4", "figura5", "figura6", "figura7", "figura8", "figura9", "figura10"]
        performSegue(withIdentifier: "irBotonera", sender: ["category": "figures"])
        playSound()
    }

    @IBAction func BTN_Colores(_ sender: Any) {
        vocabulary = ["Rojo", "Azul", "Verde", "Amarillo", "Morado", "Naranja", "Rosado", "Negro", "Blanco", "Gris"]
        videoNames = ["color1", "color2", "color3", "color4", "color5", "color6", "color7", "color8", "color9", "color10"]
        performSegue(withIdentifier: "irBotonera", sender: ["category": "colors"])
        playSound()
    }

    @IBAction func BTN_Familia(_ sender: Any) {
        vocabulary = ["Papá", "Mamá", "Hermano", "Hermana", "Abuelo", "Abuela", "Tío", "Tía", "Primo", "Primas"]
        videoNames = ["familia1", "familia2", "familia3", "familia4", "familia5", "familia6", "familia7", "familia8", "familia9", "familia10"]
        performSegue(withIdentifier: "irBotonera", sender: ["category": "family"])
        playSound()
    }

    @IBAction func BTN_Alimentos(_ sender: Any) {
        vocabulary = ["Manzana", "Plátano", "Zanahoria", "Pan", "Arroz", "Leche", "Queso", "Pollo", "Fresa", "Uvas"]
        videoNames = ["alimento1", "alimento2", "alimento3", "alimento4", "alimento5", "alimento6", "alimento7", "alimento8", "alimento9", "alimento10"]
        performSegue(withIdentifier: "irBotonera", sender: ["category": "foods"])
        playSound()
    }

    @IBAction func BTN_TRIVIA(_ sender: Any) {
        performSegue(withIdentifier: "irQuestionario", sender: nil)
        playSound()
    }
    
    @IBAction func BTN_Mundo(_ sender: Any) {
        performSegue(withIdentifier: "irMundo", sender: nil)
        playSound()
    }

    @IBAction func BTN_Internet(_ sender: Any) {
        // Crea una alerta para confirmar que el usuario quiere abrir un enlace
        let alert = UIAlertController(
            title: "Aviso",
            message: "Vas a abrir un enlace dentro de la app. ¿Deseas continuar?",
            preferredStyle: .alert
        )
        

        // Botón de cancelar
        let cancelar = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)

        // Botón de aceptar que abre un navegador dentro de la app
        let aceptar = UIAlertAction(title: "Abrir", style: .default) { _ in
            if let url = URL(string: "https://arbolabc.com/") {
                let webView = WKWebView(frame: UIScreen.main.bounds) // Crea el navegador
                let request = URLRequest(url: url)
                webView.load(request)

                let webVC = UIViewController()
                webVC.view = webView

                // Botón para cerrar el navegador
                let closeButton = UIButton(frame: CGRect(x: 20, y: 40, width: 70, height: 35))
                closeButton.setTitle("Cerrar", for: .normal)
                closeButton.setTitleColor(.systemBlue, for: .normal)
                closeButton.backgroundColor = .white
                closeButton.layer.cornerRadius = 5
                closeButton.addTarget(self, action: #selector(self.dismissPresented), for: .touchUpInside)
                webVC.view.addSubview(closeButton)

                self.present(webVC, animated: true, completion: nil) // Muestra el navegador
            }
        }

        // Agrega ambos botones a la alerta
        alert.addAction(cancelar)
        alert.addAction(aceptar)

        // Muestra la alerta
        present(alert, animated: true, completion: nil)
        playSound()
    }

    @objc func dismissPresented() {
        self.dismiss(animated: true, completion: nil)
    }

    func playSound() {
        guard let url = Bundle.main.url(forResource: "Sonido", withExtension: "mp3") else { return }
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Error reproduciendo el sonido: \(error.localizedDescription)")
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "irBotonera" {
            if let botoneraVC = segue.destination as? Vocabulario {
                botoneraVC.vocabulary = vocabulary
                botoneraVC.videoNames = videoNames
                if let data = sender as? [String: String], let category = data["category"] {
                    botoneraVC.category = category
                }
            }
        }
    }
    @IBAction func BTN_Perfil(_ sender: Any) {
        performSegue(withIdentifier: "irPerfil", sender: nil)
        playSound()
    }
}
