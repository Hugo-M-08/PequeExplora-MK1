//
//  Vocabulario.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//

import UIKit
import AVKit
import FirebaseStorage // NUEVO

class Vocabulario: UIViewController {

    @IBOutlet weak var BTN_Regreso: UIButton!
    @IBOutlet weak var Pantallita: UIView!
    @IBOutlet weak var CambioIngles: UISwitch!

    var audioPlayer: AVAudioPlayer?
    var vocabulary: [String] = []
    var videoNames: [String] = []
    var category: String = ""
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?

    @IBOutlet var buttons: [UIButton]?

    let translations: [String: [String: String]] = [
        "animals": ["Perro": "Dog", "Gato": "Cat", "Elefante": "Elephant", "León": "Lion", "Tigre": "Tiger", "Mono": "Monkey", "Oso": "Bear", "Zorro": "Fox", "Pájaro": "Bird", "Serpiente": "Snake"],
        "figures": ["Círculo": "Circle", "Cuadrado": "Square", "Triángulo": "Triangle", "Rectángulo": "Rectangle", "Pentágono": "Pentagon", "Hexágono": "Hexagon", "Cubo": "Cube", "Esfera": "Sphere", "Cono": "Cone", "Cilindro": "Cylinder"],
        "colors": ["Rojo": "Red", "Azul": "Blue", "Verde": "Green", "Amarillo": "Yellow", "Morado": "Purple", "Naranja": "Orange", "Rosado": "Pink", "Negro": "Black", "Blanco": "White", "Gris": "Gray"],
        "family": ["Papá": "Dad", "Mamá": "Mom", "Hermano": "Brother", "Hermana": "Sister", "Abuelo": "Grandfather", "Abuela": "Grandmother", "Tío": "Uncle", "Tía": "Aunt", "Primo": "Cousin", "Primas": "Cousins"],
        "foods": ["Manzana": "Apple", "Plátano": "Banana", "Zanahoria": "Carrot", "Pan": "Bread", "Arroz": "Rice", "Leche": "Milk", "Queso": "Cheese", "Pollo": "Chicken", "Fresa": "Strawberry", "Uvas": "Grapes"]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Redondear botones
        buttons?.forEach {
            $0.layer.cornerRadius = $0.frame.height / 2
            $0.clipsToBounds = true
        }

        // Cargar idioma guardado
        let savedEnglish = UserDefaults.standard.bool(forKey: "isEnglishMode")
        CambioIngles.isOn = savedEnglish

        updateButtonTitles()
    }

    override var prefersStatusBarHidden: Bool { true }

    // Reproduce video desde Firebase
    @IBAction func buttonTapped(_ sender: UIButton) {
        guard let buttons = buttons, let index = buttons.firstIndex(of: sender) else { return }
        guard index < videoNames.count else { return }

        player?.pause()
        player = nil
        playerLayer?.removeFromSuperlayer()

        let baseName = videoNames[index]
        let isEnglish = CambioIngles.isOn
        let videoFileName = isEnglish ? "\(baseName)ingles.mp4" : "\(baseName).mp4"
        let folderName: String

        switch category {
        case "animals": folderName = "Animales"
        case "figures": folderName = "Figuras"
        case "colors":  folderName = "Colores"
        case "family":  folderName = "Familia"
        case "foods":   folderName = "Alimentos"
        default: return
        }

        let langFolder = isEnglish ? "Ingles" : "Espanol"
        let path = "Vocabulario/Videos/\(langFolder)/\(folderName)/\(videoFileName)"

        let storageRef = Storage.storage().reference().child(path)

        // Obtiene URL pública de Firebase
        storageRef.downloadURL { url, error in
            if let error = error {
                print("Error cargando video: \(error.localizedDescription)")
                return
            }
            guard let videoURL = url else { return }

            DispatchQueue.main.async {
                self.player = AVPlayer(url: videoURL)
                self.playerLayer = AVPlayerLayer(player: self.player)
                self.playerLayer?.frame = self.Pantallita.bounds
                self.playerLayer?.videoGravity = .resizeAspect
                self.Pantallita.layer.addSublayer(self.playerLayer!)
                self.player?.play()
            }
        }
    }

    @IBAction func BTN_Regreso(_ sender: Any) {
        player?.pause()
        player = nil
        playerLayer?.removeFromSuperlayer()
        performSegue(withIdentifier: "regreso1", sender: nil)
        playSound()
    }

    // Guardar preferencia al cambiar idioma
    @IBAction func CambioIngles(_ sender: UISwitch) {
        UserDefaults.standard.set(sender.isOn, forKey: "isEnglishMode")
        updateButtonTitles()
        playSound()
    }

    func playSound() {
        guard let url = Bundle.main.url(forResource: "Sonido", withExtension: "mp3") else { return }
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Error sonido: \(error)")
        }
    }

    private func updateButtonTitles() {
        guard let buttons = buttons else { return }
        let isEnglish = CambioIngles.isOn

        for (index, button) in buttons.enumerated() {
            guard index < vocabulary.count else { break }
            let wordES = vocabulary[index]
            if isEnglish, let translated = translations[category]?[wordES] {
                button.setTitle(translated, for: .normal)
            } else {
                button.setTitle(wordES, for: .normal)
            }
        }
    }
}
