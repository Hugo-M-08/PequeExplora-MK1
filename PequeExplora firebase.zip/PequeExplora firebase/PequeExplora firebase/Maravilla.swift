//
//  Maravilla.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//
import Foundation
import FirebaseFirestore

// 1. Estructura para decodificar los documentos (no es Codable)
struct Maravilla {
    // El ID se leerá y asignará manualmente
    let id: String
    let nombre: String
    let descripcion: String
    let latitud: Double
    let longitud: Double
}

// 2. Enum para mapear los IDs de los documentos en Firebase
enum MaravillaKey: String {
    case piramideGiza = "piramide_giza"
    case colosoRodas = "coloso_rodas"
    case estatuaZeus = "estatua_zeus"
    case jardinesBabilonia = "jardines_babilonia"
    case faroAlejandria = "faro_alejandria"
    case mausoleoHalicarnaso = "mausoleo_halicarnaso"
    case temploArtemisa = "templo_artemisa"
}
