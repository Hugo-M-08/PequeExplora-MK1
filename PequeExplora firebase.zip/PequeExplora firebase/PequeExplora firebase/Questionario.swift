//
//  Questionario.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//
import UIKit
import AVFoundation
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth

protocol TriviaDelegate: AnyObject {
    func triviaDidFinish(with score: Int)
}

class Questionario: UIViewController {

    // MARK: - Propiedades de Firebase y Estado
    
    let db = Firestore.firestore()
    let storage = Storage.storage()
    
    var preguntas: [Pregunta] = []
    var paso = 0 // Índice de la pregunta actual (0, 1, 2...)
    var puntuacionActual = 0 // Puntuación acumulada (10 pts por respuesta correcta)
    
    weak var delegate: TriviaDelegate?

    // MARK: - Outlets
    
    @IBOutlet weak var SW_Traduccion: UISwitch!
    @IBOutlet weak var BTN_DictarPregunta: UIButton!
    @IBOutlet weak var BTN_A: UIButton!
    @IBOutlet weak var BTN_B: UIButton!
    @IBOutlet weak var BTN_C: UIButton!
    @IBOutlet weak var BTN_D: UIButton!
    @IBOutlet weak var BTN_Salir: UIButton!
    @IBOutlet weak var IV_MostrarImagen: UIImageView!
    @IBOutlet weak var Lbl_MostrarPregunta: UILabel!

    var audioPlayer: AVAudioPlayer?
    var audioPlayer1: AVAudioPlayer?
    let synthesizer = AVSpeechSynthesizer()

    // MARK: - Ciclo de Vida y Carga de Datos
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SW_Traduccion.isOn = false
        
        // Bloqueamos la interacción hasta que los datos se carguen
        configurarBotones(habilitados: false)
        cargarPreguntasDesdeFirebase()
    }
    
    func configurarBotones(habilitados: Bool) {
        BTN_A.isEnabled = habilitados
        BTN_B.isEnabled = habilitados
        BTN_C.isEnabled = habilitados
        BTN_D.isEnabled = habilitados
        BTN_DictarPregunta.isEnabled = habilitados
    }

    func cargarPreguntasDesdeFirebase() {
        // RUTA AJUSTADA A TU ESTRUCTURA: Trivia -> preguntas (doc) -> Pregunta1 (col)
        db.collection("Trivia")
          .document("preguntas")
          .collection("Pregunta1")
          .order(by: FieldPath.documentID())
          .getDocuments { [weak self] (snapshot, error) in
            
            guard let self = self else { return }
            
            if let error = error {
                print("🚨 Error al cargar preguntas: \(error.localizedDescription)")
                DispatchQueue.main.async { self.Lbl_MostrarPregunta.text = "Error de conexión." }
                return
            }
            
            guard let documents = snapshot?.documents else { return }
            
            DispatchQueue.main.async {
                for document in documents {
                    do {
                        // Usamos JSONSerialization para decodificar los Mapas anidados
                        let data = try JSONSerialization.data(withJSONObject: document.data(), options: [])
                        // Asume que la struct Pregunta está definida en tu proyecto
                        let pregunta = try JSONDecoder().decode(Pregunta.self, from: data)
                        self.preguntas.append(pregunta)
                    } catch {
                        print("❌ Error al decodificar la pregunta \(document.documentID): \(error)")
                    }
                }
                
                if !self.preguntas.isEmpty {
                    self.configurarBotones(habilitados: true)
                    self.mostrarPreguntaActual()
                } else {
                    self.Lbl_MostrarPregunta.text = "No se encontraron preguntas."
                }
            }
        }
    }
    
    // Función para descargar la imagen de Firebase Storage
    func cargarImagen(nombre: String) {
        let imageRef = storage.reference(withPath: "Trivia/imagenes/\(nombre)")
        
        imageRef.getData(maxSize: 1 * 1024 * 1024) { [weak self] data, error in
            guard let self = self else { return }
            
            if let error = error {
                print("⚠️ Error al descargar imagen de Storage: \(error.localizedDescription)")
                DispatchQueue.main.async { self.IV_MostrarImagen.image = nil }
                return
            }
            
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.IV_MostrarImagen.image = image
                }
            }
        }
    }

    // Muestra la pregunta actual y sus opciones
    func mostrarPreguntaActual() {
        guard paso < preguntas.count else {
            // Fin del cuestionario
            guardarRanking(puntos: puntuacionActual)
            mostrarAlertaFinal()
            return
        }
        
        let pregunta = preguntas[paso]
        // Asume que la función getTraduccion está disponible en la struct Pregunta
        let traduccion = pregunta.getTraduccion(esIngles: SW_Traduccion.isOn)
        
        // Mostrar texto y cargar imagen
        Lbl_MostrarPregunta.text = traduccion.pregunta
        BTN_A.setTitle(traduccion.A, for: .normal)
        BTN_B.setTitle(traduccion.B, for: .normal)
        BTN_C.setTitle(traduccion.C, for: .normal)
        BTN_D.setTitle(traduccion.D, for: .normal)
        
        cargarImagen(nombre: pregunta.imagenID)
    }

    // Verifica si la respuesta es correcta y avanza
    func verificarRespuesta(_ letraSeleccionada: String) {
        guard paso < preguntas.count else { return }
        
        let preguntaActual = preguntas[paso]
        let esCorrecta = letraSeleccionada == preguntaActual.respuestaCorrecta
        
        if esCorrecta {
            playSound("correcto")
            puntuacionActual += 10
        } else {
            playSound("incorrecto")
        }
        
        // Avanza a la siguiente pregunta
        paso += 1
        mostrarPreguntaActual()
    }

    // ⭐ FUNCIÓN CORREGIDA: Guarda el UID real del usuario en el ranking
    func guardarRanking(puntos: Int) {
        // 🚨 CORRECCIÓN CLAVE: Usamos el UID real para que VerPerfil lo pueda encontrar
        guard let uid = Auth.auth().currentUser?.uid else {
            print("⚠️ No hay usuario autenticado. No se guardó el ranking.")
            return
        }
        
        let datosRanking: [String: Any] = [
            "puntos": puntos,
            "usuario": uid, // ⬅️ Ahora guarda el UID correcto
            "fecha": Timestamp(date: Date())
        ]
        
        db.collection("Ranking").addDocument(data: datosRanking) { error in
            if let error = error {
                print("Error al guardar el ranking: \(error)")
            } else {
                print("🎉 Ranking guardado: \(puntos) puntos para UID: \(uid).")
            }
        }
    }
    
    // Alerta Final AÑADIDA la opción de Ver Ranking
    func mostrarAlertaFinal() {
        let alert = UIAlertController(
            title: "¡Juego Terminado!",
            message: "Has completado el cuestionario con \(puntuacionActual) puntos. Tu puntuación fue registrada.",
            preferredStyle: .alert
        )
    
        
        let aceptar = UIAlertAction(title: "Regresar al Inicio", style: .cancel) { _ in
            self.performSegue(withIdentifier: "regreso3", sender: nil)
        }
        alert.addAction(aceptar)
        present(alert, animated: true, completion: nil)
    }
    
    // MARK: - Acciones @IBAction

    @IBAction func BTN_A(_ sender: UIButton) { verificarRespuesta("A") }
    @IBAction func BTN_B(_ sender: UIButton) { verificarRespuesta("B") }
    @IBAction func BTN_C(_ sender: UIButton) { verificarRespuesta("C") }
    @IBAction func BTN_D(_ sender: UIButton) { verificarRespuesta("D") }
    
    @IBAction func SW_TraduccionChanged(_ sender: UISwitch) { mostrarPreguntaActual() }
    @IBAction func BNT_SALIR(_ sender: Any) { performSegue(withIdentifier: "regreso3", sender: nil); playSound1() }
    
    @IBAction func BTN_DictarPregunta(_ sender: Any) {
        guard let texto = Lbl_MostrarPregunta.text else { return }

        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }

        let utterance = AVSpeechUtterance(string: texto)
        utterance.voice = AVSpeechSynthesisVoice(language: SW_Traduccion.isOn ? "en-US" : "es-MX")
        utterance.rate = 0.5
        synthesizer.speak(utterance)
    }
    
    // MARK: - Funciones de Audio
    
    func playSound(_ name: String) {
        if let url = Bundle.main.url(forResource: name, withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            } catch {
                print("Error al reproducir \(name): \(error)")
            }
        }
    }
    
    func playSound1() {
        guard let url = Bundle.main.url(forResource: "Sonido", withExtension: "mp3") else { return }
        do {
            audioPlayer1 = try AVAudioPlayer(contentsOf: url)
            audioPlayer1?.play()
        } catch {
            print("Error reproduciendo el sonido: \(error.localizedDescription)")
        }
    }
}
