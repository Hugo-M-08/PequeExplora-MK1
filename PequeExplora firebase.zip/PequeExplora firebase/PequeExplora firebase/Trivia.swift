//
//  Trivia.swift
//  PequeExplora firebase
//
//  Created by Hugo Manuel Antonio Rangel on 08/12/25.
//
import Foundation
import FirebaseFirestore

// Estructura para el contenido traducido (espanol/ingles)
struct Traduccion: Decodable {
    let pregunta: String
    let A: String
    let B: String
    let C: String
    let D: String
}

// Estructura principal de la pregunta
struct Pregunta: Decodable {
    let imagenID: String
    let respuestaCorrecta: String // Letra de la respuesta correcta (ej. "B")
    let espanol: Traduccion
    let ingles: Traduccion
    
    // Función de ayuda para obtener la traducción correcta
    func getTraduccion(esIngles: Bool) -> Traduccion {
        return esIngles ? ingles : espanol
    }
}

// Estructura para cargar y mostrar las puntuaciones del Ranking
struct Puntuacion {
    let puntos: Int
    let usuario: String
    let fecha: Date // Firebase Timestamp se convierte aquí
}
